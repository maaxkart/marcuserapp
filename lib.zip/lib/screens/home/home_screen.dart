import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../widgets/course_card.dart';
import '../../widgets/category_chip.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;
  final ScrollController _scrollController = ScrollController();
  int _selectedCategory = 0;

  final List<Map<String, dynamic>> _categories = [
    {'label': 'All', 'icon': '✦'},
    {'label': 'Design', 'icon': '🎨'},
    {'label': 'Dev', 'icon': '💻'},
    {'label': 'Business', 'icon': '📈'},
    {'label': 'AI & ML', 'icon': '🤖'},
    {'label': 'Marketing', 'icon': '📣'},
  ];

  final List<Map<String, dynamic>> _courses = [
    {
      'title': 'UI/UX Mastery',
      'instructor': 'Sarah Chen',
      'rating': 4.9,
      'students': '12.4K',
      'duration': '24h',
      'price': '\$89',
      'tag': 'Bestseller',
      'tagColor': AppColors.accentGold,
      'gradient': [Color(0xFF7C3AED), Color(0xFF3B82F6)],
      'progress': 0.0,
    },
    {
      'title': 'Flutter Advanced',
      'instructor': 'Alex Rivera',
      'rating': 4.8,
      'students': '8.1K',
      'duration': '32h',
      'price': '\$119',
      'tag': 'New',
      'tagColor': AppColors.accentCyan,
      'gradient': [Color(0xFF059669), Color(0xFF06D6D6)],
      'progress': 0.0,
    },
    {
      'title': 'AI Foundations',
      'instructor': 'Dr. Priya Nair',
      'rating': 4.9,
      'students': '21.3K',
      'duration': '40h',
      'price': '\$149',
      'tag': 'Hot',
      'tagColor': Color(0xFFEF4444),
      'gradient': [Color(0xFFDC2626), Color(0xFF7C3AED)],
      'progress': 0.0,
    },
    {
      'title': 'Brand Strategy',
      'instructor': 'Marcus Webb',
      'rating': 4.7,
      'students': '5.6K',
      'duration': '18h',
      'price': '\$79',
      'tag': 'Popular',
      'tagColor': AppColors.accentGold,
      'gradient': [Color(0xFFD97706), Color(0xFFEC4899)],
      'progress': 0.0,
    },
  ];

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnim = CurvedAnimation(parent: _animController, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(
      begin: const Offset(0, 0.06),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _animController, curve: Curves.easeOut));
    _animController.forward();
  }

  @override
  void dispose() {
    _animController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.backgroundSoft,
      child: FadeTransition(
        opacity: _fadeAnim,
        child: SlideTransition(
          position: _slideAnim,
          child: CustomScrollView(
            controller: _scrollController,
            physics: const BouncingScrollPhysics(),
            slivers: [
              _buildSliverAppBar(),
              SliverToBoxAdapter(child: _buildBody()),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSliverAppBar() {
    return SliverAppBar(
      expandedHeight: 0,
      floating: true,
      snap: true,
      backgroundColor: AppColors.backgroundSoft,
      elevation: 0,
      flexibleSpace: const FlexibleSpaceBar(),
      title: _buildAppBarContent(),
      centerTitle: false,
      actions: [
        _buildNotificationButton(),
        const SizedBox(width: 8),
        _buildSearchButton(),
        const SizedBox(width: 16),
      ],
    );
  }

  Widget _buildAppBarContent() {
    return Row(
      children: [
        Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF9D5FF5), Color(0xFF5B21B6)],
            ),
            borderRadius: BorderRadius.circular(10),
          ),
          child: const Center(
            child: Text(
              'M',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: Colors.white,
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        const Text(
          'Marc App',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
            letterSpacing: -0.5,
          ),
        ),
      ],
    );
  }

  Widget _buildNotificationButton() {
    return Stack(
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: AppColors.backgroundGrey,
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Icon(
            Icons.notifications_outlined,
            color: AppColors.textSecondary,
            size: 20,
          ),
        ),
        Positioned(
          top: 8,
          right: 8,
          child: Container(
            width: 8,
            height: 8,
            decoration: const BoxDecoration(
              color: AppColors.accentGold,
              shape: BoxShape.circle,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSearchButton() {
    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        color: AppColors.backgroundGrey,
        borderRadius: BorderRadius.circular(12),
      ),
      child: const Icon(
        Icons.search_rounded,
        color: AppColors.textSecondary,
        size: 20,
      ),
    );
  }

  Widget _buildBody() {
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 100),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildGreetingSection(),
          const SizedBox(height: 24),
         // _buildStatsRow(),
         // const SizedBox(height: 28),
          _buildFeaturedBanner(),
          const SizedBox(height: 28),
          _buildCategorySection(),
          const SizedBox(height: 24),
          _buildCoursesSection(),
          const SizedBox(height: 28),
          _buildContinueLearningSection(),
          const SizedBox(height: 28),
          _buildTopInstructors(),
        ],
      ),
    );
  }

  Widget _buildGreetingSection() {
    final hour = DateTime.now().hour;

    String greeting;
    if (hour < 12) {
      greeting = "Good Morning";
    } else if (hour < 17) {
      greeting = "Good Afternoon";
    } else {
      greeting = "Good Evening";
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          /// 🔥 MAIN TEXT (Rich Style)
          RichText(
            text: TextSpan(
              children: [
                const TextSpan(
                  text: "Hey ",
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),

                /// 👤 Highlighted Name
                TextSpan(
                  text: "Nowfal",
                  style: const TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF6C63FF), // premium accent
                  ),
                ),

                const TextSpan(
                  text: ", ",
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),

                /// 🌅 Greeting
                TextSpan(
                  text: greeting,
                  style: const TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),

                const TextSpan(
                  text: " 👋",
                  style: TextStyle(fontSize: 24),
                ),
              ],
            ),
          ),

          const SizedBox(height: 8),

          /// ✨ SUBTEXT
          Text(
            "Let’s build something amazing today 🚀",
            style: TextStyle(
              fontSize: 14,
              color: AppColors.textSecondary.withOpacity(0.8),
              fontWeight: FontWeight.w400,
            ),
          ),

        ],
      ),
    );
  }
  Widget _buildStatsRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          Expanded(
            child: StatsCard(
              value: '12',
              label: 'Enrolled',
              icon: Icons.school_rounded,
              color: AppColors.accentViolet,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: StatsCard(
              value: '4',
              label: 'Completed',
              icon: Icons.check_circle_rounded,
              color: AppColors.accentCyan,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: StatsCard(
              value: '86h',
              label: 'Learning',
              icon: Icons.timer_rounded,
              color: AppColors.accentGold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeaturedBanner() {
    return const Padding(
      padding: EdgeInsets.symmetric(horizontal: 20),
      child: FeaturedBanner(),
    );
  }

  Widget _buildCategorySection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Text(
            'Categories',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
              letterSpacing: -0.3,
            ),
          ),
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 44,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            physics: const BouncingScrollPhysics(),
            itemCount: _categories.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (_, index) => CategoryChip(
              label: _categories[index]['label'],
              icon: _categories[index]['icon'],
              isSelected: _selectedCategory == index,
              onTap: () => setState(() => _selectedCategory = index),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCoursesSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Popular Courses',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                  letterSpacing: -0.3,
                ),
              ),
              TextButton(
                onPressed: () {},
                child: const Text(
                  'See all',
                  style: TextStyle(
                    color: AppColors.accentVioletLight,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 240,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            physics: const BouncingScrollPhysics(),
            itemCount: _courses.length,
            separatorBuilder: (_, __) => const SizedBox(width: 14),
            itemBuilder: (_, index) => CourseCard(data: _courses[index]),
          ),
        ),
      ],
    );
  }

  Widget _buildContinueLearningSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Text(
            'Continue Learning',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
              letterSpacing: -0.3,
            ),
          ),
        ),
        const SizedBox(height: 14),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              _buildContinueCard(
                title: 'UI/UX Mastery',
                instructor: 'Sarah Chen',
                progress: 0.65,
                lesson: 'Lesson 14: Prototyping',
                gradient: const [Color(0xFF7C3AED), Color(0xFF3B82F6)],
              ),
              const SizedBox(height: 12),
              _buildContinueCard(
                title: 'Flutter Advanced',
                instructor: 'Alex Rivera',
                progress: 0.28,
                lesson: 'Lesson 6: State Management',
                gradient: const [Color(0xFF059669), Color(0xFF06D6D6)],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildContinueCard({
    required String title,
    required String instructor,
    required double progress,
    required String lesson,
    required List<Color> gradient,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: AppColors.border,
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: gradient),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(
              Icons.play_arrow_rounded,
              color: Colors.white,
              size: 24,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  lesson,
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppColors.textMuted,
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(4),
                        child: LinearProgressIndicator(
                          value: progress,
                          backgroundColor: AppColors.surfaceLight,
                          valueColor: AlwaysStoppedAnimation<Color>(gradient[0]),
                          minHeight: 4,
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      '${(progress * 100).toInt()}%',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: gradient[0],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: AppColors.backgroundGrey,
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(
              Icons.arrow_forward_rounded,
              color: AppColors.textSecondary,
              size: 18,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopInstructors() {
    final instructors = [
      {'name': 'Sarah Chen', 'field': 'UI/UX Design', 'students': '12.4K'},
      {'name': 'Alex Rivera', 'field': 'Flutter Dev', 'students': '8.1K'},
      {'name': 'Dr. Priya Nair', 'field': 'AI & ML', 'students': '21K'},
      {'name': 'Marcus Webb', 'field': 'Branding', 'students': '5.6K'},
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Top Instructors',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                  letterSpacing: -0.3,
                ),
              ),
              TextButton(
                onPressed: () {},
                child: const Text(
                  'See all',
                  style: TextStyle(
                    color: AppColors.accentVioletLight,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 130,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            physics: const BouncingScrollPhysics(),
            itemCount: instructors.length,
            separatorBuilder: (_, __) => const SizedBox(width: 14),
            itemBuilder: (_, index) {
              final inst = instructors[index];
              final colors = [
                [const Color(0xFF7C3AED), const Color(0xFF3B82F6)],
                [const Color(0xFF059669), const Color(0xFF06D6D6)],
                [const Color(0xFFDC2626), const Color(0xFF7C3AED)],
                [const Color(0xFFD97706), const Color(0xFFEC4899)],
              ];
              return Container(
                width: 100,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: AppColors.border,
                    width: 1,
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: colors[index]),
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                        child: Text(
                          inst['name']![0],
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      inst['name']!.split(' ')[0],
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      inst['students']!,
                      style: const TextStyle(
                        fontSize: 10,
                        color: AppColors.textMuted,
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}