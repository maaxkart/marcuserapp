import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';

class CommunityScreen extends StatefulWidget {
  const CommunityScreen({super.key});
  @override
  State<CommunityScreen> createState() => _CommunityScreenState();
}

class _CommunityScreenState extends State<CommunityScreen> {
  int _selectedTab = 0;
  final _tabs = ['🔥 Trending', '💡 Unanswered', '🏆 Top Rated', '📘 FAQs'];

  final _posts = [
    {
      'name': 'Sarah Chen',
      'time': '2 min ago · UI/UX',
      'badge': 'Expert',
      'badgeColor': Color(0xFF059669),
      'badgeBg': Color(0xFFD1FAE5),
      'gradient': [Color(0xFF7C3AED), Color(0xFF3B82F6)],
      'text': 'Best practice for design tokens in Figma when handing off to Flutter? Anyone using token studio?',
      'tags': ['#figma', '#flutter', '#tokens'],
      'likes': 24, 'comments': 12, 'liked': true,
    },
    {
      'name': 'Alex Rivera',
      'time': '18 min ago · Flutter',
      'badge': 'Mentor',
      'badgeColor': Color(0xFF6C63FF),
      'badgeBg': Color(0xFFEDE9FE),
      'gradient': [Color(0xFF059669), Color(0xFF06D6D6)],
      'text': 'Riverpod vs Bloc in 2025 — which state management are you all actually shipping with?',
      'tags': ['#riverpod', '#bloc'],
      'likes': 41, 'comments': 28, 'liked': false,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F4FF),
      floatingActionButton: _buildFAB(),
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          _buildAppBar(),
          SliverToBoxAdapter(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildAppBar() {
    return SliverAppBar(
      floating: true,
      snap: true,
      backgroundColor: const Color(0xFFF5F4FF),
      elevation: 0,
      expandedHeight: 0,
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Community',
            style: TextStyle(
              fontSize: 26, fontWeight: FontWeight.w800,
              color: Color(0xFF1A1A2E), letterSpacing: -0.5,
            ),
          ),
          Text(
            '4.2K members active',
            style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
          ),
        ],
      ),
      actions: [
        Container(
          width: 38, height: 38,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFF6C63FF).withOpacity(0.15)),
          ),
          child: const Icon(Icons.notifications_outlined, size: 18, color: Color(0xFF6C63FF)),
        ),
        const SizedBox(width: 8),
        Container(
          width: 38, height: 38,
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF6C63FF), Color(0xFF9D5FF5)]),
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Icon(Icons.search_rounded, size: 18, color: Colors.white),
        ),
        const SizedBox(width: 16),
      ],
    );
  }

  Widget _buildBody() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSearch(),
        const SizedBox(height: 16),
        _buildTabs(),
        const SizedBox(height: 20),
        _buildActiveMembersSection(),
        const SizedBox(height: 20),
        _buildPostsSection(),
        const SizedBox(height: 20),
        _buildFAQSection(),
        const SizedBox(height: 100),
      ],
    );
  }

  Widget _buildSearch() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFF6C63FF).withOpacity(0.15), width: 1.5),
        ),
        child: const TextField(
          decoration: InputDecoration(
            hintText: 'Search questions, topics...',
            hintStyle: TextStyle(color: Color(0xFF9CA3AF), fontSize: 13),
            border: InputBorder.none,
            icon: Icon(Icons.search, color: Color(0xFF9CA3AF), size: 18),
            contentPadding: EdgeInsets.symmetric(vertical: 12),
          ),
        ),
      ),
    );
  }

  Widget _buildTabs() {
    return SizedBox(
      height: 38,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        itemCount: _tabs.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) {
          final active = _selectedTab == i;
          return GestureDetector(
            onTap: () => setState(() => _selectedTab = i),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                gradient: active
                    ? const LinearGradient(colors: [Color(0xFF6C63FF), Color(0xFF9D5FF5)])
                    : null,
                color: active ? null : Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: active
                    ? null
                    : Border.all(color: const Color(0xFF6C63FF).withOpacity(0.15)),
              ),
              child: Text(
                _tabs[i],
                style: TextStyle(
                  fontSize: 12, fontWeight: FontWeight.w600,
                  color: active ? Colors.white : Colors.grey.shade500,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildActiveMembersSection() {
    final members = [
      {'name': 'Sarah', 'role': 'Designer', 'online': true,
        'colors': [Color(0xFF7C3AED), Color(0xFF3B82F6)]},
      {'name': 'Alex', 'role': 'Dev', 'online': true,
        'colors': [Color(0xFF059669), Color(0xFF06D6D6)]},
      {'name': 'Priya', 'role': 'AI/ML', 'online': false,
        'colors': [Color(0xFFDC2626), Color(0xFF7C3AED)]},
      {'name': 'Marcus', 'role': 'Brand', 'online': true,
        'colors': [Color(0xFFD97706), Color(0xFFEC4899)]},
      {'name': 'You', 'role': 'Nowfal', 'online': true,
        'colors': [Color(0xFF0EA5E9), Color(0xFF6366F1)]},
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionHeader('Active Members'),
        const SizedBox(height: 12),
        SizedBox(
          height: 90,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            itemCount: members.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (_, i) {
              final m = members[i];
              return SizedBox(
                width: 64,
                child: Column(
                  children: [
                    Stack(
                      children: [
                        Container(
                          width: 48, height: 48,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: m['colors'] as List<Color>,
                            ),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: Center(
                            child: Text(
                              (m['name'] as String)[0],
                              style: const TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w800,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                        if (m['online'] as bool)
                          Positioned(
                            bottom: 2, right: 2,
                            child: Container(
                              width: 10, height: 10,
                              decoration: BoxDecoration(
                                color: const Color(0xFF10B981),
                                shape: BoxShape.circle,
                                border: Border.all(color: Colors.white, width: 1.5),
                              ),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(m['name'] as String,
                        style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600),
                        overflow: TextOverflow.ellipsis),
                    Text(m['role'] as String,
                        style: const TextStyle(fontSize: 9, color: Color(0xFF9CA3AF))),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildPostsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionHeader('Discussions'),
        const SizedBox(height: 12),
        ...List.generate(_posts.length, (i) => _buildPostCard(_posts[i])),
      ],
    );
  }

  Widget _buildPostCard(Map post) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF6C63FF).withOpacity(0.1)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 10),
              child: Row(
                children: [
                  Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: post['gradient'] as List<Color>),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Center(
                      child: Text(
                        (post['name'] as String)[0],
                        style: const TextStyle(
                          fontSize: 14, fontWeight: FontWeight.w800, color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(post['name'] as String,
                            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
                        Text(post['time'] as String,
                            style: const TextStyle(fontSize: 11, color: Color(0xFF9CA3AF))),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: post['badgeBg'] as Color,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      post['badge'] as String,
                      style: TextStyle(
                        fontSize: 10, fontWeight: FontWeight.w700,
                        color: post['badgeColor'] as Color,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(post['text'] as String,
                      style: const TextStyle(fontSize: 13, color: Color(0xFF374151), height: 1.6)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    children: (post['tags'] as List<String>).map((tag) => Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: const Color(0xFF6C63FF).withOpacity(0.08),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(tag, style: const TextStyle(
                          fontSize: 11, fontWeight: FontWeight.w600, color: Color(0xFF6C63FF))),
                    )).toList(),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
              decoration: const BoxDecoration(
                border: Border(top: BorderSide(color: Color(0xFFF3F4F6))),
              ),
              child: Row(
                children: [
                  _actionBtn(
                    icon: Icons.favorite_rounded,
                    label: '${post['likes']}',
                    active: post['liked'] as bool,
                    activeColor: const Color(0xFFEF4444),
                  ),
                  const SizedBox(width: 16),
                  _actionBtn(icon: Icons.chat_bubble_outline_rounded, label: '${post['comments']}'),
                  const SizedBox(width: 16),
                  _actionBtn(icon: Icons.share_outlined, label: 'Share'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _actionBtn({
    required IconData icon,
    required String label,
    bool active = false,
    Color activeColor = const Color(0xFF9CA3AF),
  }) {
    final color = active ? activeColor : const Color(0xFF9CA3AF);
    return Row(
      children: [
        Icon(icon, size: 16, color: color),
        const SizedBox(width: 4),
        Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: color)),
      ],
    );
  }

  Widget _buildFAQSection() {
    final faqs = [
      {'icon': Icons.school_outlined, 'text': 'How to enroll in a course?'},
      {'icon': Icons.download_outlined, 'text': 'How to download my certificate?'},
      {'icon': Icons.person_outline_rounded, 'text': 'How to contact my instructor?'},
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionHeader('FAQs'),
        const SizedBox(height: 12),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: faqs.map((faq) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: const Color(0xFF6C63FF).withOpacity(0.1)),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 32, height: 32,
                      decoration: BoxDecoration(
                        color: const Color(0xFF6C63FF).withOpacity(0.08),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(faq['icon'] as IconData, size: 16, color: const Color(0xFF6C63FF)),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(faq['text'] as String,
                          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                    ),
                    const Icon(Icons.chevron_right_rounded, color: Color(0xFF9CA3AF), size: 18),
                  ],
                ),
              ),
            )).toList(),
          ),
        ),
      ],
    );
  }

  Widget _sectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: const TextStyle(
              fontSize: 16, fontWeight: FontWeight.w700, color: Color(0xFF1A1A2E))),
          Text('See all', style: const TextStyle(
              fontSize: 12, fontWeight: FontWeight.w600, color: Color(0xFF6C63FF))),
        ],
      ),
    );
  }

  Widget _buildFAB() {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF6C63FF), Color(0xFF9D5FF5)]),
        borderRadius: BorderRadius.circular(18),
        boxShadow: [BoxShadow(
          color: const Color(0xFF6C63FF).withOpacity(0.4),
          blurRadius: 24, offset: const Offset(0, 8),
        )],
      ),
      child: FloatingActionButton.extended(
        onPressed: () {},
        backgroundColor: Colors.transparent,
        elevation: 0,
        icon: const Icon(Icons.chat_bubble_outline_rounded, color: Colors.white, size: 18),
        label: const Text('Ask Doubt',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
      ),
    );
  }
}